# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\Rusheel\Desktop\BSC Computer Science\Python\pycharm\finalGUI\forcasting.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class forcasting_MainWindow(object):
    def setupUi(self, ForcastWindow):
        ForcastWindow.setObjectName("ForcastWindow")
        ForcastWindow.setGeometry(QtCore.QRect(0, 0, 620, 436))
        self.centralwidget = QtWidgets.QWidget(ForcastWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(260, 10, 121, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.forcastFrame = QtWidgets.QFrame(self.centralwidget)
        self.forcastFrame.setGeometry(QtCore.QRect(110, 60, 401, 281))
        self.forcastFrame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.forcastFrame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.forcastFrame.setObjectName("forcastFrame")
        self.back = QtWidgets.QPushButton(self.centralwidget)
        self.back.setGeometry(QtCore.QRect(520, 360, 75, 23))
        self.back.setObjectName("back")
        ForcastWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(ForcastWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 620, 21))
        self.menubar.setObjectName("menubar")
        ForcastWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(ForcastWindow)
        self.statusbar.setObjectName("statusbar")
        ForcastWindow.setStatusBar(self.statusbar)

        self.retranslateUi(ForcastWindow)
        QtCore.QMetaObject.connectSlotsByName(ForcastWindow)

    def retranslateUi(self, ForcastWindow):
        _translate = QtCore.QCoreApplication.translate
        ForcastWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "The Forcast"))
        self.back.setText(_translate("MainWindow", "Back"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ForcastWindow = QtWidgets.QMainWindow()
    ui = forcasting_MainWindow()
    ui.setupUi(ForcastWindow)
    ForcastWindow.show()
    sys.exit(app.exec_())
