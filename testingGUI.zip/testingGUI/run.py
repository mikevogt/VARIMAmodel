from PyQt5.QtGui import *
import os
import csv
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import pandas as pd
from PyQt5.uic.properties import QtWidgets
from loginWindow import login_MainWindow
from forcastParametrs import parametrs_MainWindow
from forcasting import forcasting_MainWindow


class run(QMainWindow, login_MainWindow, parametrs_MainWindow, forcasting_MainWindow):
    def __init__(self, *args, **kwargs):
        super(run, self).__init__(*args, **kwargs)
        self.setupUi(self)

        # giving buttons functions
        self.pushButton.pressed.connect(self.signIN)
        self.focastButton.pressed.connect(self.forcast)

        self.show()


if __name__ == '__main__':
    app = QApplication([])
    app.setApplicationName("PyQt Calculator")

    window = run()
    app.exec_()
